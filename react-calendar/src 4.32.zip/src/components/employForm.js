import React, { useState }from 'react'

const EmployForm = () => {

    const [showForm, setShowForm] = useState(false);

    function closePopup() {
        setShowForm(false);
    }

    const [addEmployee, setAddEmployee] = useState({
           username:"",
           email:"",
           phone:"",
           wage:"",
           role:""
    });
    const [records, setRecoeds] = useState([]);

    const handleInput = (e) => {
        const name = e.target.name;
        const value = e.target.value;
        console.log(name, value);
        
        setAddEmployee({ ...addEmployee, [name]: value})
    }

    const handleSubmit = (e) => {
        e.preventDefault();

        const newRecord = {...addEmployee, id: new Date().getTime().toString()}

        setRecoeds([...records, newRecord]);
        console.log(records);

        setAddEmployee({
        username:"",
        email:"",
        phone:"",
        wage:"",
        role:"" 
        });
    }

  return (
    <>
    { !showForm && <button onClick={() => setShowForm(true)}>Add Employee</button> }
    
      { showForm && (
      
        <form action="" onSubmit={handleSubmit}>
            <div>
                <label htmlFor="username">Employee name</label>
                <input type="text" autoComplete="off" 
                value={addEmployee.username}
                onChange={handleInput}
                name="username" id="username"/>
            </div>
            <div>
                <label htmlFor="email">email</label>
                <input type="text" autoComplete="off" 
                value={addEmployee.email}
                onChange={handleInput}
                name="email" id="email"/>
            </div>
            <div>
                <label htmlFor="phone">phone</label>
                <input type="number" autoComplete="off" 
                value={addEmployee.phone}
                onChange={handleInput}
                name="phone" id="phone"/>
            </div>
            <div>
                <label htmlFor="wage">Hourly Wage</label>
                <input type="text" autoComplete="off" 
                value={addEmployee.wage}
                onChange={handleInput}
                name="wage" id="wage"/>
            </div>
            <div>
                <label htmlFor="role">Role</label>
                <input type="text" autoComplete="off" 
                value={addEmployee.role}
                onChange={handleInput}
                name="role" id="role"/>
            </div>

            <button type="submit" >Add employee</button>
            <button type="submit" onClick={closePopup}>cancel</button>
        </form>
        
      )}
      <div>
        {
            records.map((curElem) => {
                const { id, username, email, phone, wage, role } = curElem;
                return(
                    <div className="result-view" key={id}>
                        <p className='result-block-view'>{username}</p>
                        <p className='result-block-view'>{email}</p>
                        <p className='result-block-view'>{phone}</p>
                        <p className='result-block-view'>{wage}</p>
                        <p className='result-block-view'>{role}</p>
                    </div>
                )
            })
        }
      </div>
    </>
  )
}

export default EmployForm