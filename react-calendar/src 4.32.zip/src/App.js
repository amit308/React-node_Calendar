// import React, { Fragment } from 'react';
// import './App.css';

// import Calendar from './components/calendar';

// function App() {
//   return (
//     <Fragment>
//       <section className="hero is-primary">
//         <div className="hero-body">
//           <div className="container">
//             <h1 className="title has-text-centered">Calendar</h1>
//           </div>
//         </div>
//       </section>
//       <div className="container has-text-centered">
//         <Calendar />
//       </div>
//     </Fragment>
//   );
// }

// export default App;


import React, { Fragment } from 'react';
import './App.css';
import EmployForm from './components/employForm';
import Calendar from './components/calendar';

function App() {
  return (
    <Fragment>
      <section >
        <div>
          <div className='heading'>
            <h1 >Calendar</h1>
          </div>
        </div>
      </section>
      <div>
        <Calendar />
        <EmployForm />
      </div>
    </Fragment>
    
  );
}

export default App;